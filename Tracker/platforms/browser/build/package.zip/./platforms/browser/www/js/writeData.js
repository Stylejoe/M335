function writeNewData(uid, latitude, longitude)
{
    var locationHistory = {
        uid: uid,
        latitude: latitude,
        longitude: longitude,
        timestamp: timestamp
    };
}